<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;

$factory->define(\App\Club::class, function (Faker $faker) {
    return [
        //
    ];
});
