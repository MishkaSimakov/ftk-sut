require('./bootstrap');
require('@fortawesome/fontawesome-free/js/all');

window.Vue = require('vue');

import Vuex from 'vuex';
Vue.use(Vuex);

// import { Editor } from 'tinymce'
// window.Editor = Editor;

// import { ImageUpload } from 'quill-image-upload';
// window.ImageUpload = ImageUpload;

import Cropper from 'cropperjs';
window.Cropper = Cropper;

require('./quill.js');
window.Quill = require('Quill');

// window.ClassicEditor = require('@ckeditor/ckeditor5-build-classic');

// chat
Vue.component('chats', require('./components/chat/Chats.vue').default);
Vue.component('chat', require('./components/chat/Chat.vue').default);
Vue.component('message', require('./components/chat/Message.vue').default);
Vue.component('chat-users', require('./components/chat/ChatUsers.vue').default);

Vue.component('chat-button', require('./components/chat/ChatButton.vue').default);

Vue.component('chat-add-form', require('./components/chat/forms/ChatAddForm.vue').default);
Vue.component('message-add-form', require('./components/chat/forms/MessageAddForm.vue').default);
Vue.component('chat-user-add-form', require('./components/chat/forms/ChatUserAddForm.vue').default);
Vue.component('chat-name-form', require('./components/chat/forms/ChatNameForm.vue').default);

//comments
Vue.component('comments', require('./components/comments/Comments.vue').default);
Vue.component('comment', require('./components/comments/Comment.vue').default);
Vue.component('comment-add-form', require('./components/comments/AddCommentForm.vue').default);

// articles
Vue.component('tags-add-form', require('./components/article/AddTagForm.vue').default);
Vue.component('find-articles-form', require('./components/article/FindArticlesForm.vue').default);
Vue.component('writers-top', require('./components/article/writersTop.vue').default);
Vue.component('articles-top', require('./components/article/articlesTop.vue').default);
Vue.component('comments-top', require('./components/article/recentComments.vue').default);

// home
Vue.component('new-chat-button', require('./components/home/NewChatButton.vue').default);
Vue.component('user-photo', require('./components/user/Photo.vue').default);

// rating
// Vue.component('rating', require('./components/rating/Rating.vue').default);

import store from './store/index.js'

import './Notifications'

const app = new Vue({
    el: '#app',
    store: store
});
