<template>

</template>

<script>
    export default {
        name: "LikeButton"
    }
</script>

<style scoped>

</style>
