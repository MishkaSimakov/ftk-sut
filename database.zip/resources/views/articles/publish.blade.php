@extends('layouts.page')

@section('content')

<h1 class="text-center m-2">Требуют проверки</h1>

<div class="m-3">
    @component('components.card-lists.articles', ['articles' => $articles])@endcomponent
</div>

@endsection

@push('script')
    <script>
        $(document).ready(function() {
            $('.article__body').each(function () {
                if ($(this).children('#article_text').height() >= 500) {
                    $(this).children('#article_read_more').show()
                }
            })
        });
    </script>
@endpush
