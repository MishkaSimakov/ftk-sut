<section class="section">
    <div class="container">
        <h2 class="section__header">{{ $header }}</h2>
        {{ $slot }}
    </div>
</section>
