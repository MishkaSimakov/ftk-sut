<header>
    @include('partials.header.nav')
</header>
