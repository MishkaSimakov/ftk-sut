@extends('layouts.page')

@section('content')
    <chats></chats>
@endsection
