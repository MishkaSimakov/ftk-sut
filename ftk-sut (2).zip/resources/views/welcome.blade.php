@include('partials.header')

<h1 class="text-center m-2">Фототехнический клуб</h1>

<p class="m-2">Здесь должно идти очень долгое описание всего о клубе, но это сделает кто-то другой (или я через много много лет)...</p>
<p class="m-2">Пусть пока здесь побуду я :)</p>
<img class="m-2" alt="здесь я, если что. Но всё-таки проверьте интернет" src="https://sun9-16.userapi.com/c855724/v855724995/8561d/24QFZOC8was.jpg">

@include('partials.footer')