</main>
</div>

@yield('script')
</body>
</html>