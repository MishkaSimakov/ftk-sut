@include('partials.header')

<h1 class="text-center">Регистрация</h1>

<p>Чтобы зарегистрироваться напишите Симакову Михаилу</p>

@include('partials.footer')