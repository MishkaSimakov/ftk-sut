@extends('layouts.page')

@section('content')
    <chat id="{{ $chat->id }}"></chat>
@endsection
